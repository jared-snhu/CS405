// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
#include <stdexcept>  // std::out_of_range, std::length_error
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 //TEST_F(CollectionTest, AlwaysFail)
 //{
 //  FAIL();
 //}

 // Adding one value to an empty collection makes the size 1
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // collection starts empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    // no longer empty, and the size is 1
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1);
}

// Adding five values makes the size 5
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    EXPECT_EQ(collection->size(), 5);
}

// max_size() is >= size for 0, 1, 5, and 10 entries
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToSize)
{
    // 0 entries (add_entries can't add 0)
    ASSERT_EQ(collection->size(), 0);
    EXPECT_GE(collection->max_size(), collection->size());

    // 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    EXPECT_GE(collection->max_size(), collection->size());

    // 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    EXPECT_GE(collection->max_size(), collection->size());

    // 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    EXPECT_GE(collection->max_size(), collection->size());
}

// capacity() is >= size for 0, 1, 5, and 10 entries
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToSize)
{
    // 0 entries (checked first, since add_entries does not allow 0)
    ASSERT_EQ(collection->size(), 0);
    EXPECT_GE(collection->capacity(), collection->size());

    // 1 entry
    add_entries(1);
    ASSERT_EQ(collection->size(), 1);
    EXPECT_GE(collection->capacity(), collection->size());

    // 5 entries
    add_entries(4);
    ASSERT_EQ(collection->size(), 5);
    EXPECT_GE(collection->capacity(), collection->size());

    // 10 entries
    add_entries(5);
    ASSERT_EQ(collection->size(), 10);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Resizing larger increases the size
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    collection->resize(10);

    EXPECT_EQ(collection->size(), 10);
}

// Resizing smaller decreases the size
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10);

    collection->resize(5);

    EXPECT_EQ(collection->size(), 5);
}

// Resizing to 0 empties the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// clear() empties the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// erase(begin, end) empties the collection
TEST_F(CollectionTest, EraseBeginEndErasesCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0);
}

// reserve() raises the capacity but not the size
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);
    size_t old_size = collection->size();
    size_t old_capacity = collection->capacity();

    collection->reserve(old_capacity + 10);

    EXPECT_GT(collection->capacity(), old_capacity);
    EXPECT_EQ(collection->size(), old_size);
}

// Negative test: at() with a bad index throws std::out_of_range
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // index 10 is out of bounds (cast to void since the value isn't used)
    EXPECT_THROW(static_cast<void>(collection->at(10)), std::out_of_range);
}

// Custom positive test: pop_back() removes only the last value
TEST_F(CollectionTest, PopBackRemovesLastValue)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5);

    // the first 4 values should be all that's left
    std::vector<int> expected(collection->begin(), collection->end() - 1);

    collection->pop_back();

    EXPECT_EQ(collection->size(), 4);
    EXPECT_EQ(*collection, expected);
}

// Custom negative test: reserving more than max_size() throws std::length_error
TEST_F(CollectionTest, ReserveMoreThanMaxSizeThrowsLengthError)
{
    ASSERT_TRUE(collection->empty());

    EXPECT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);

    // collection is unchanged
    EXPECT_TRUE(collection->empty());
}
