// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];
  std::cout << "Enter a value: ";

  // setw to limit the characters cin can read to avoid overflow in array
  std::cin >> std::setw(sizeof(user_input)) >> user_input;

  // If leftover characters are still in the stream, the input was too long
  // warn the user and clear them out
  if (std::cin.peek() != '\n' && !std::cin.eof())
  {
    std::cout << "Warning: your input was too long and has been truncated." << std::endl;
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
